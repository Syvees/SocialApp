const db = require('../models'); // Adjust path as necessary
const User = db.User;
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const UserController = {
    register: async (req, res) => {
        try {
          const { first_name, last_name, username, email, password } = req.body;
    
          // Input validation
          if (!first_name || !last_name || !username || !email || !password) {
            return res.status(400).json({ message: "Please provide all required fields" });
          }
    
          const existingUser = await User.findOne({ where: { email } });
    
          if (existingUser) {
            return res.status(400).json({ message: "User already exists" });
          }
    
          const newUser = await User.create({ first_name, last_name, username, email, password });
    
          res.status(201).json({ message: "Registration successful", user: newUser });
        } catch (error) {
          console.error('Error during registration:', error);
    
          // Handle other errors
          res.status(500).json({ message: 'Internal Server Error' });
        }
      },

    login: async (req, res) => {
        try {
            const { email, password } = req.body;
            const user = await User.findOne({ where: { email } });

            if (!user) {
                return res.status(400).json({ message: "Invalid email" });
            }
            if (!password) {
                return res.status(400).json({ message: "Invalid password" });
            }

            const userToken = jwt.sign({ id: user.id }, process.env.JWT_SECRET);
            res
            .cookie("usertoken", userToken, { httpOnly: true })
            .json({ msg: "success!" });
        } catch (error) {
            res.status(400).json(error);
        }
    },

    logout: (req, res) => {
        res.clearCookie('usertoken');
        res.sendStatus(200);
    },

    getUserById: async (req, res) => {
      const userId = req.params.id;
      try {
        const userDetails = await User.findByPk(userId);
        if (userDetails) {
          res.json(userDetails);
        } else {
          res.status(404).json({ error: 'User not found' });
        }
      } catch (error) {
        console.error('Error fetching user details:', error);
        res.status(500).json({ error: 'Error fetching user details' });
      }
    },
    getUsers: (req, res) => {
        User.findAll({})
            .then(allUsers => res.json(allUsers))
            .catch(err => res.json(err))
    }

};

module.exports = UserController;