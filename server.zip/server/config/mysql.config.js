const host = "localhost";
const user = "root";
const password = "root";
const db = "social_app";
const dialect = "mysql";


module.exports = {
    HOST: host,
    USER: user,
    PASSWORD: password,
    DB: db,
    dialect: dialect
};